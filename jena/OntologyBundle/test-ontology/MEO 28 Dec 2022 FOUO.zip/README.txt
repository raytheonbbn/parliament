
					  This technical data deliverable was developed using
					  contract funds under Basic Contract No. W56KGU-21-F-0008. 
					  © 2022 The MITRE Corporation. 

The Military Equipment Ontologies (MEO) - 29 December 2022

This package contains the MEO Ontologies in 4 variants plus the term definitions on which they are based:

1) All Merged - terms and codes merged into single ontologies:
	CLO - Curation and Labeling Ontology - annotation properties used for labeling - tracks the DIOWG P&G specification and will be replaced by it when its officially released
	OPO - Other People's Ontologies Ontology - all terms used from CCO/BFO
	2 merged ontologies - all term ontologies merged into all_terms.owl and all code ontologies into all_codes.owl (same contents as in the partitioned versions)

2) All-Partitioned
	CLO - Curation and Labeling Ontology - annotation properties used for labeling - tracks the DIOWG P&G specification and will be replaced by it when its officially released
	OPO - Other People's Ontologies Ontology - all terms used from CCO/BFO
	13 term ontologies - the terms and defined classes partitioned into 13 domains (aircraft, ground vehicles, ...). The terms are all unclassified 
	13 code ontologies - all the DIEQP codes described with the vocabulary from the term ontologies, partitioned into 13 domains (paralleling the term ontologies). The codes are unclassified or FOUO and their definitions and AKAs are individually marked.
	2 import only ontologies - consists of only import statements that include all term ontologies (import_all_terms.owl) or all code ontologies (import_all_codes.owl)
	
3) All-Phase 1 - Subset of all terms and codes for Phase 1 focus areas (Ground Vehicles, Aircraft and Watercraft)
	CLO - Curation and Labeling Ontology - annotation properties used for labeling - tracks the DIOWG P&G specification and will be replaced by it when its officially released
	OPO - Other People's Ontologies Ontology - all terms used from CCO/BFO
	2 merged ontologies - all phase 1 terms merged into all_terms.owl and all phase 1 codes into all_codes.owl

4) Codes with Aspects - flattened ontologies
	Codes with Aspects FOUO.xlsx - This is an attempt to flatten the ontology into a tabular form while preserving as much information and structure as possible.
	Each piece of equipment is described by 36 aspects which are drawn from the axioms and relations defined in the ontologies.

5) The "Handbook Vocab" spreadsheet contains the term definitions and supporting information that drives the ontology development process and is organized as:

Tabs
	Equipment Code Categories - reference information describing DIEQP Coding scheme
	Canonicals - mapping from vocabulary used in DIEQP nomenclature to canonical English form
	Swaps - used by transformation software to swap or replace terms
	Terms - primary content - terms, definitions and supporting information (see below for details)
	Properties - the relations used in the term definitions
	BFO-CCO Defs - the terms from CommonCore and Basic Formal Ontologies and those we build on
	Future MEPED Terms - terms in development to support integration of MEPED data sets
	Scratch Ammo Terms - ongoing work to normalize highly jargonized/compressed/abbreviated/undefined terms used in ammunition codes

	Terms Tab
		Term Index - numerical value, used to form the IRI for the term
		Source - whether the term was found in the equipment code nomenclature, added to complete the term taxonomy or added to support future expansion for the MEPED data sets
		NomenType - either an "entity" - artifact or material object or "Modifier" a characteristic or feature
		AxiomType - whether the term will become a subclass or equivalence (defined class)
		Term - the term being defined, becomes the label of the class
		ParentTerm - superclass term and Subject of Subject-Predicate-Object triple if term is a defined (equivalence) definition
		property - object property that, with the ObjectTerm field forms the logical definition of the Term
		ObjectTerm - the "object" part of a Predicate-Object tuple
		Definition - textual definition of the term
		bibliographicCitation - source of the textual definition
		Classification - classification marking for the term and definition
	  Below fields are primarily used in internal QC and other development tasks.	
		Has Parent Def - (internal) Check to confirm Parent Term has a definition
		Category - topical categorization for terms
		Partition - domain of term, determines what ontology term goes into
		Status - Whether the term should be included or excluded form the ontologies
		Phase - (internal) QC phase 
		TermCount - (internal) how many times this term occurred in DIEQP codes
		NumTier1 - (internal) how many distinct Tier 1 types the term occurred with
		NumTier2 - (internal) how many distinct Tier 2 types the term occurred with
		SeenCategories - (internal)In what Equipment Code categories did the term appear
		Num ObjectTypes - (internal) Number of Equipment COde object types did the term occur with
		ObjectTypes - (internal) the equipment code object types the term occur with
	
 Status -
 MEO is a work in progress. Still to be done:
 
1) The contents of the "definition" field is auto-generated from the axioms and varies in quality. Auto-generated definitions begin with a "~" tilde.
2) The partitioned version of the ontologies are missing some imports so some definitions don't display their labels. These will display as "ont_<number>" instead of the label.
3) The "aspect" terms (functions and qualities) have not been fully reconciled with CCO/BFO and appear as subclasses of "Aspect" rather than the BFO/CCO class
4) The MEO Design Document is still under development and not included in this package.
5) The mapping to/from and integration of content from the JIKO (and possibly other IC/DoD ontologies) is just beginning.
	